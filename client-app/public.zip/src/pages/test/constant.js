export const STATUS_MAP = {
    READY: 2,
    RUNNING: 3,
    FINISH: 4,
}  